%consider the system in part1 exercise 1help 
b = [1 5]; 
a = [1 2 3];

o = linspace(-20,20,200);
s = linspace(-5,5,200);

%system response matrix
[sigmagrid,omegagrid] = meshgrid(s,o);

sgrid = sigmagrid+j*omegagrid;

%evaluate the numerator and denominator polynomials
H1 = polyval(b,sgrid)./polyval(a,sgrid);

%surface graph of the magnitude of H(s)
mesh(s,o,20*log10(abs(H1)));
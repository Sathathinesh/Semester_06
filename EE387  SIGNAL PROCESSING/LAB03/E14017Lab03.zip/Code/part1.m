a1 = [1 5];
b1 = [1 2 3];
z1 = roots(a1);
p1 = roots(b1);
subplot(3,1,1);
pzmap(p1,z1);

a2 = [2 5 12];
b2 = [1 2 10];
z2 = roots(a2);
p2 = roots(b2);
subplot(3,1,2);
pzmap(p2,z2);

a3 = [2 5 12];
b3 = [1 4 14 20];
z3 = roots(a3);
p3 = roots(b3);
subplot(3,1,3);
pzmap(p3,z3);
a = [2 2 17];
b = [1 4 104];
o = linspace(-20,20,200);

x = freqs(a,b,o);
subplot(3,1,1);
plot(o, abs(x),'b');

subplot(3,1,2)
plot(o, angle(x),'y');

x1=tf(a,b);
subplot(3,1,3)
bode(x1,'r');


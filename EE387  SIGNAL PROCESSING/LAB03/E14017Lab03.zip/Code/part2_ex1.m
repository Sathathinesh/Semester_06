a1 = [1 -1]; 
b1 = [1 3 2];

a2 = [1 5]; 
b2 = [1 2 3];

a3 = [2 5 12]; 
b3 = [1 2 10];

a4 = [2 5 12]; 
b4 = [1 4 14 20];

x1=tf(a1,b1);
subplot(4,1,1)
bode(x1);

x2=tf(a2,b2);
subplot(4,1,2)
bode(x2);

x3=tf(a3,b3);
subplot(4,1,3)
bode(x3);

x4=tf(a4,b4);
subplot(4,1,4)
bode(x4);

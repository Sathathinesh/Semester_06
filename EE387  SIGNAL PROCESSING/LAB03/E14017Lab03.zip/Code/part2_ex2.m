syms s;
t = linspace(-20,20,200);

lh1 = (s-1)./(s*s+2*s+2);
lh2 = (s+5)./(s*s+2*s+3);
lh3 = (2*s*s+5*s+12)./(s*s+2*s+10);
lh4 = (2*s*s+5*s+12)./(s.^3+4*s*s+14*s+20);

w1 = 2*pi*17*1;
w2 = 2*pi*17*2;
w3 = 2*pi*17*3;

x1 = sin(w1*t);
x2 = sin(w2*t);
x3 = sin(w3*t);

%give signal x1 to all the systems
ly11 = lx1.*lh1;
y11 = ilaplace(ly11)

ly12 = lx1.*lh2;
y12 = ilaplace(ly12)

ly13 = lx1.*lh3;
y13 = ilaplace(ly13)

ly14 = lx1.*lh4;
y14 = ilaplace(ly14)

%give signal x2 to all the systems
ly21 = lx2.*lh1;
y21 = ilaplace(ly21)

ly22 = lx2.*lh2;
y22 = ilaplace(ly22)

ly23 = lx2.*lh3;
y23 = ilaplace(ly23)

ly24 = lx2.*lh4;
y24 = ilaplace(ly24)

%give signal x3 to all the systems
ly31 = lx3.*lh1;
y31 = ilaplace(ly31)

ly32 = lx3.*lh2;
y32 = ilaplace(ly32)

ly33 = lx3.*lh3;
y33 = ilaplace(ly33)

ly34 = lx3.*lh4;
y34 = ilaplace(ly34)






